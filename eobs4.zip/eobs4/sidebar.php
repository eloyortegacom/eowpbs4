      <div id="sidebar" class="col-md-3">
        <?php if(!dynamic_sidebar('sidebar')) : ?>
        <h3>sidebar</h3>
        <p>Pon algo de contenido aquí.</p>
      <?php endif; ?>
      </div>
