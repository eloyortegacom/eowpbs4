      <div id="sidebar" class="col-md-3">
        <?php if(!dynamic_sidebar('blog')) : ?>
        <h3>sidebar blog</h3>
        <p>Pon algo de contenido aquí.</p>
      <?php endif; ?>
      </div>
