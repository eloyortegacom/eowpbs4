jQuery(document).ready(function () {
  jQuery('[data-toggle="offcanvas"]').click(function () {
    jQuery('.row-offcanvas').toggleClass('active visible')
  });
});

/*Menú OffCanvas*/
jQuery(document).ready(function () {
  
  var contador = 1;
    jQuery('[data-toggle="offcanvas"]').click(function () {
      jQuery('#offcanvas-eo-menu').toggleClass('si');    
     if (contador==1){     
      jQuery('.navbar-toggle').addClass('abierto');
      jQuery('.bt-menu').addClass('fa-times');
      jQuery('.bt-menu').removeClass('fa-bars');
      contador=0;
    } else {
     if (contador==0){     
      jQuery('.navbar-toggle').removeClass('abierto');
      jQuery('.bt-menu').addClass('fa-bars');
      jQuery('.bt-menu').removeClass('fa-times');
      contador=1;
    }
  }
  });
});

  //mostrar y ocultar submenus
    //unbind es para evitar que el código se ejecute varias veces cuando el menú se abra varias veces
    //al final con sacar esta función de dentro de la anterior ha bastado :)
  jQuery('.padre').click(function () {
        jQuery(this).children('.sub-menu').slideToggle();    

  });
